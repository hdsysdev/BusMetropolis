The D3 work is in the "@Bus UMLmodel" files. 

All the best!